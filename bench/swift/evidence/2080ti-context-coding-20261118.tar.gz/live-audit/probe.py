import sys
from pathlib import Path
from types import SimpleNamespace
sys.path[:0]=["bench","src"]
from swift_qwen import complete, render_tokens, template_probe, MARKER
from qah.executor import ReferenceExecutor
from qah.telemetry import Monitor
from campaign_report import atomic_json
out=Path("live-audit")
x=SimpleNamespace(url="http://127.0.0.1:8080", request_timeout=1800, process=SimpleNamespace(pid=23082))
x.json=lambda *args: ReferenceExecutor.json(x,*args)
x.tokenize=lambda text: ReferenceExecutor.tokenize(x,text)
mode=template_probe(x,out)
tokens=render_tokens(x,mode,120000)
for name,cached in [("cold",False),("cached",True)]:
    with Monitor(x,output=out/(name+"-telemetry.jsonl")) as monitor:
        result=complete(x,tokens,512,cached)
    result.update(resources=monitor.report(),retrieval_pass=result["final_answer"]==MARKER)
    atomic_json(out/(name+".json"),result)
    t=result["timings"]
    print(name,t,"TTFT",result["ttft_seconds"],"retrieval",result["retrieval_pass"],flush=True)
    if t["prompt_n"]+t["cache_n"]!=len(tokens) or (bool(t["cache_n"])!=cached):
        raise RuntimeError("unexpected cache counters")
